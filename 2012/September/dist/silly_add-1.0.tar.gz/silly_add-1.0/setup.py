#!/usr/bin/env python

from distutils.core import setup

setup(name='silly_add',
		version='1.0',
		py_modules=['silly_add'],
		)
